-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2011 at 08:30 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scshare`
--
CREATE DATABASE `scshare` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `scshare`;

-- --------------------------------------------------------

--
-- Table structure for table `pms`
--

CREATE TABLE IF NOT EXISTS `pms` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender_id` bigint(20) NOT NULL,
  `reciever_id` bigint(20) NOT NULL,
  `sender_name` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL,
  `message` text NOT NULL,
  `new` tinyint(1) NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `pms`
--

INSERT INTO `pms` (`id`, `sender_id`, `reciever_id`, `sender_name`, `title`, `message`, `new`, `time`) VALUES
(48, 6, 8, 'hell', '', 'qwd:', 0, '2011-03-27 01:27:14'),
(37, 8, 8, 'pos', 'title:', 'asfawegawegwaeg', 0, '2011-03-24 04:07:19'),
(49, 8, 8, 'pos', '', 'qwdwqf', 1, '2011-03-27 01:27:54'),
(10, 14, 14, 'test', 'test', 'oiwefioawoiefiweaof', 0, '2011-03-21 15:40:45'),
(11, 14, 14, 'test', 'uywiewegwa', 'WEF', 0, '2011-03-21 15:41:06'),
(65, 6, 6, 'hell', 'tgcg', 'hjjhhhvhvghffg', 0, '2011-04-17 21:06:45'),
(66, 6, 6, 'hell', 'oh noes', 'hello im here to talk about your sale.... blah blah.\r\naarhawrr', 0, '2011-04-17 21:19:39'),
(67, 6, 6, 'hell', 'awgawegwaeg', 'waegagawegawegawe', 0, '2011-04-20 13:29:04');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender_id` bigint(20) NOT NULL,
  `sender_username` varchar(32) CHARACTER SET utf8 NOT NULL,
  `item_name` varchar(64) CHARACTER SET utf8 NOT NULL,
  `discription` text CHARACTER SET utf8 NOT NULL,
  `other` tinytext CHARACTER SET utf8 NOT NULL,
  `condition` varchar(32) CHARACTER SET utf8 NOT NULL,
  `bid` tinyint(1) NOT NULL DEFAULT '0',
  `picture` text CHARACTER SET utf8 NOT NULL,
  `pic_size` int(32) NOT NULL,
  `category` varchar(32) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `sender_id`, `sender_username`, `item_name`, `discription`, `other`, `condition`, `bid`, `picture`, `pic_size`, `category`, `time`) VALUES
(29, 6, 'hell', 'anime set', 'yug', 'ftitf', 'like new', 0, 'uploaded_images/395d2c6252b90d111ff374fc7df1971bd2', 1355831, 'electronics', '2011-03-27 10:33:59'),
(34, 15, 'password', 'sdgse', '', '', 'dirty', 0, 'uploaded_images/486c0e0e8135a4de90d03506280940df90', 37596, 'furniture', '2011-04-15 20:30:39'),
(35, 6, 'hell', 'anime stuff', '', '', 'never opened', 1, 'uploaded_images/3903af7616db07e37eb02f32a299ec9367', 919747, 'books', '2011-04-16 13:36:27'),
(31, 6, 'hell', 'eshrsth', 'ersgersgre', 'esherh', 'scratched', 0, 'uploaded_images/392366bdd52af0c5ce1e3932ce0494bc06', 362752, 'electronics', '2011-03-27 22:15:57'),
(36, 6, 'hell', 'somethinn', '', 'wefawegawe', 'slightly worn', 0, 'uploaded_images/390889c531633201dadb7bc048748c35df', 919747, 'electronics', '2011-04-20 13:29:37'),
(33, 6, 'hell', 'weagaweg', 'awefawegwaeg', 'waefaweg', 'poor', 0, 'uploaded_images/39a3fa9fbb436c076e1f07ca6ac5bf1f11', 362752, 'books', '2011-04-15 16:44:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `messages` int(32) NOT NULL,
  `new_messages` int(11) NOT NULL,
  `user_ip` bigint(20) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` tinyint(1) NOT NULL,
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `email`, `name`, `messages`, `new_messages`, `user_ip`, `time`, `admin`, `ID`) VALUES
('pos', '5e0bdcbddccca4d66d74ba8c1cee1a68', 'alavro@retard.com', 'pos', 0, 0, 0, '2011-03-09 14:43:39', 0, 8),
('ol', '9cdfb439c7876e703e307864c9167a15', 'imocha@aol.com', 'melo', 0, 0, 0, '2011-03-09 03:46:47', 0, 7),
('hell', 'fe17ec3c451f132ef82a3a54e84a461e', 'imoca@aol.com', 'lal', 3, 0, 0, '2011-04-20 13:29:06', 1, 6),
('eiry', 'def6d90e829e50c63f98c387daecd138', 'tol@aolc.om', 'awior', 0, 0, -2116884129, '2011-03-09 18:55:13', 0, 9),
('hello', 'e203dedf4441205b61adf50c8efad497', 'ITA@aol.com', 'lolp', 0, 0, 0, '2011-03-09 19:07:45', 0, 10),
('post', '42b90196b487c54069097a68fe98ab6f', 'post@aol.om', 'post', 0, 0, 0, '2011-03-09 19:08:40', 0, 11),
('this', '9e925e9341b490bfd3b4c4ca3b0c1ef2', 'are@aol.com', 'awlk', 0, 0, -1062731517, '2011-03-20 22:34:35', 0, 12),
('gara', '04b7aaeab58d4c6507e86a90250694af', 'olo@aol.com', 'het', 0, 0, 0, '2011-03-21 00:47:13', 0, 13),
('test', '098f6bcd4621d373cade4e832627b4f6', 'test@test.com', 'test', 0, 0, 0, '2011-03-21 15:40:13', 0, 14),
('password', '5f4dcc3b5aa765d61d8327deb882cf99', 'password@hotmail.com', 'password', 0, 0, -2116884300, '2011-04-15 20:27:22', 0, 15),
('lizhongsan', '5ed325d1675eb230cecfd29c77ed704a', 'pli@scu.edu', 'Paul', 0, 0, -2116919259, '2011-05-06 18:52:24', 0, 16);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
